import "../../chunks/index-server.js";
import { a as ensure_array_like, c as stringify, i as derived, n as attr_class, r as attr_style, z as escape_html } from "../../chunks/dev.js";
//#region src/routes/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let groups = [];
		let cd = {
			"Aging": `00`,
			"AF": `10`,
			"OIS": `20`,
			"Tilt": `30`,
			"Tilt-Ro": `32`,
			"Prism": `40`,
			"Fra-AF": `50`,
			"Fra-OIS": `60`,
			"Flag": `70`
		};
		let actionControl = "command";
		let modelMap = {
			10840: "MD10840",
			16849: "MD16849",
			15342: "MD15342",
			12338: "MD12338",
			18049: "MD18049",
			11542: "MD11542",
			15984: "MD15984",
			17997: "MD17997",
			17748: "P17748"
		};
		let mays = [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9
		];
		let modelconfig = null;
		let connect = false;
		let lastPing = Date.now();
		let natLoginState = false;
		let countData = derived(() => {
			let total = 0;
			groups.forEach((m) => {
				for (const tenCongDoan in m.congdoan) {
					const danhSachMay = m.congdoan[tenCongDoan];
					for (const idMay in danhSachMay) {
						const may = danhSachMay[idMay];
						if (may.connect?.color === "OK" && may.merge?.value) {
							const val = parseInt(may.merge.value);
							if (!isNaN(val)) total += val;
						}
					}
				}
			});
			return total;
		});
		let reportControl = null;
		let rp = derived(() => {
			return reportControl;
		});
		async function loadStatus() {
			try {
				const res = await fetch("/api/clientStatus");
				console.log(res.status);
				if (res.status === 401) {
					window.location.href = "/login";
					return;
				}
				if (!res.ok) throw new Error("API Error");
				const data = await res.json();
				if (data.type === "status") {
					console.log(data);
					lastPing = Date.now();
					const payload = data.data;
					groups = payload.model;
					modelconfig = payload.masterconfig.modelconfig;
					payload.masterconfig.md5map;
					payload.masterconfig.regmap;
					connect = payload.connect;
					natLoginState = payload.natlogin;
					payload.filelist;
				}
			} catch (e) {
				console.error(e);
			}
		}
		loadStatus();
		setInterval(() => {
			loadStatus();
			if (Date.now() - lastPing > 5e3) {
				console.log("Mất kết nối server");
				connect = false;
			}
		}, 1e3);
		`${window.location.origin}`;
		`${window.location.origin}`;
		`${window.location.origin}`;
		`${window.location.origin}`;
		$$renderer.push(`<main class="svelte-1uha8ag"><div class="TopBox svelte-1uha8ag"><div class="TopDiv svelte-1uha8ag"><button type="button" class="svelte-1uha8ag">Web Api Edit</button> <button type="button" class="svelte-1uha8ag">Logout</button> <button type="button" class="svelte-1uha8ag">Register</button> <button type="button" class="svelte-1uha8ag">Permission config</button> <button type="button" class="svelte-1uha8ag">Change PassWord</button> Data : ${escape_html(countData())} let actionControl = "login"; `);
		$$renderer.select({
			value: actionControl,
			class: ""
		}, ($$renderer) => {
			$$renderer.option({
				value: "login",
				class: ""
			}, ($$renderer) => {
				$$renderer.push(`Login`);
			}, "svelte-1uha8ag");
			$$renderer.option({
				value: "command",
				class: ""
			}, ($$renderer) => {
				$$renderer.push(`Command`);
			}, "svelte-1uha8ag");
			$$renderer.option({
				value: "ver",
				class: ""
			}, ($$renderer) => {
				$$renderer.push(`Version`);
			}, "svelte-1uha8ag");
			$$renderer.option({
				value: "remove",
				class: ""
			}, ($$renderer) => {
				$$renderer.push(`Remove`);
			}, "svelte-1uha8ag");
			$$renderer.option({
				value: "active",
				class: ""
			}, ($$renderer) => {
				$$renderer.push(`Active`);
			}, "svelte-1uha8ag");
		}, "svelte-1uha8ag");
		$$renderer.push(` `);
		if (actionControl === "command") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="svelte-1uha8ag"><input type="text" id="id" placeholder="id..." class="svelte-1uha8ag"/> <input type="text" id="code" placeholder="code..." class="svelte-1uha8ag"/> <button class="svelte-1uha8ag">Send</button></div>`);
		} else if (actionControl === "ver") {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<div class="svelte-1uha8ag"><input type="text" id="modeVer" placeholder="mode Ver" class="svelte-1uha8ag"/> <input type="text" id="valueVer" placeholder="ver..." class="svelte-1uha8ag"/> <button class="svelte-1uha8ag">Send</button></div>`);
		} else if (actionControl === "active") {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`<div class="svelte-1uha8ag"><input type="text" id="activeClient" placeholder="vd:168492" class="svelte-1uha8ag"/> <button class="svelte-1uha8ag">Add</button> <button class="svelte-1uha8ag">Remove</button></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <span${attr_class(`dot ${stringify(natLoginState ? "online" : "offline")}`, "svelte-1uha8ag")}></span> Report : ${escape_html(rp())} <div style="color:black ;" id="alertBox" class="svelte-1uha8ag"></div></div></div> <div class="wrapper svelte-1uha8ag"><!--[-->`);
		const each_array = ensure_array_like([...groups].sort((a, b) => a.model_name.localeCompare(b.model_name)));
		for (let $$index_2 = 0, $$length = each_array.length; $$index_2 < $$length; $$index_2++) {
			let model = each_array[$$index_2];
			$$renderer.push(`<div class="window-wrapper svelte-1uha8ag"><div class="fixed-content svelte-1uha8ag"><div class="item svelte-1uha8ag"><section class="group-container svelte-1uha8ag"><div class="group-header svelte-1uha8ag">Line:${escape_html(modelMap[model.model_name.slice(0, 5)])}_Line ${escape_html(model.model_name.slice(5, 6))}</div> <!--[-->`);
			const each_array_1 = ensure_array_like(Object.entries(cd));
			for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
				let [congdoan_name, i] = each_array_1[$$index_1];
				const congdoan = model.congdoan[congdoan_name];
				if (congdoan) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="item svelte-1uha8ag"><div class="sub-group-section svelte-1uha8ag"><button type="button" class="sub-title svelte-1uha8ag">${escape_html(congdoan_name)}:     ${escape_html(modelconfig[`${model.model_name}${i}`]?.pgm || "N/A")}</button> <button type="button" class="sub-title svelte-1uha8ag">CRC:  ${escape_html(modelconfig[`${model.model_name}${i}`]?.pgm.split("_")[0] || "N/A")}_${escape_html(modelconfig[`${model.model_name}${i}`]?.pgm.split("_")[1] || "N/A")}_${escape_html(modelconfig[`${model.model_name}${i}`]?.crc || "N/A")}</button> <table class="svelte-1uha8ag"><thead class="taskbar svelte-1uha8ag"><tr class="svelte-1uha8ag"><th rowspan="2" class="svelte-1uha8ag">ID</th><th rowspan="2" class="svelte-1uha8ag"><button class="invisible-button svelte-1uha8ag" aria-label="resetvnc" type="button">VNC <br class="svelte-1uha8ag"/>Reset</button></th><th colspan="2" class="svelte-1uha8ag">PGM</th><th colspan="2" class="svelte-1uha8ag">CRC</th><th rowspan="2" class="svelte-1uha8ag">Data</th><th rowspan="2" class="svelte-1uha8ag">Ver</th></tr><tr class="svelte-1uha8ag"><th class="svelte-1uha8ag"><button class="invisible-button svelte-1uha8ag" aria-label="PGM locker" type="button">Locker</button></th><th class="svelte-1uha8ag">PGM Ver</th><th class="svelte-1uha8ag"><button class="invisible-button svelte-1uha8ag" aria-label="CRC locker" type="button">Locker</button></th><th class="svelte-1uha8ag">CRC Ver</th></tr></thead><tbody class="taskbar svelte-1uha8ag"><!--[-->`);
					const each_array_2 = ensure_array_like(mays);
					for (let $$index = 0, $$length = each_array_2.length; $$index < $$length; $$index++) {
						let may = each_array_2[$$index];
						const m = congdoan[may];
						$$renderer.push(`<tr style="height: 30px;" class="svelte-1uha8ag"><td class="svelte-1uha8ag"><button class="invisible-button svelte-1uha8ag" type="button">${escape_html(model.model_name)}<br class="svelte-1uha8ag"/>${escape_html(i)}${escape_html(may)}</button></td>`);
						if (m) {
							$$renderer.push("<!--[0-->");
							if (connect) {
								$$renderer.push("<!--[0-->");
								if (m.connect.color == "OK") {
									$$renderer.push("<!--[0-->");
									$$renderer.push(`<td class="svelte-1uha8ag"><button class="invisible-button svelte-1uha8ag" aria-label="resetvnc" type="button">${escape_html(m.mesid)}</button></td> <td class="svelte-1uha8ag"><button class="invisible-button svelte-1uha8ag" aria-label="PGM locker" type="button"><span${attr_class(`dot ${stringify(m.lockerpgm.value === "Locked" ? "online" : "offline")}`, "svelte-1uha8ag")}></span></button></td> <th class="svelte-1uha8ag"><span${attr_class(`dot ${stringify(m.pgm.color === "OK" ? "online" : "offline")}`, "svelte-1uha8ag")}></span></th> <td class="svelte-1uha8ag"><button class="invisible-button svelte-1uha8ag" aria-label="CRC locker" type="button"><span${attr_class(`dot ${stringify(m.lockercrc.value === "Locked" ? "online" : "offline")}`, "svelte-1uha8ag")}></span></button></td> <th class="svelte-1uha8ag"><span class="crc-text svelte-1uha8ag"${attr_style(`color:${stringify(m.crc.color === "OK" ? "green" : "red")}`)}>${escape_html(m.currentcrc)}</span></th> <td${attr_class(`status-${stringify(m.merge.color)}`, "svelte-1uha8ag")}><button class="invisible-button svelte-1uha8ag" aria-label="resetmes" type="button">${escape_html(m.merge.color === "OK" ? m.merge.value : "Fail")}</button></td> <th class="svelte-1uha8ag">SC: ${escape_html(m.ver.split("|")[0])}<br class="svelte-1uha8ag"/> LO: ${escape_html(m.ver.split("|")[1])}<br class="svelte-1uha8ag"/> UI: ${escape_html(m.ver.split("|")[2])}</th>`);
								} else {
									$$renderer.push("<!--[-1-->");
									$$renderer.push(`<td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td>`);
								}
								$$renderer.push(`<!--]-->`);
							} else {
								$$renderer.push("<!--[-1-->");
								$$renderer.push(`<td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td><td class="status-Fail svelte-1uha8ag">X</td>`);
							}
							$$renderer.push(`<!--]-->`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></tr>`);
					}
					$$renderer.push(`<!--]--></tbody></table></div></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			}
			$$renderer.push(`<!--]--></section></div></div></div>`);
		}
		$$renderer.push(`<!--]--></div></main> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
	});
}
//#endregion
export { _page as default };
