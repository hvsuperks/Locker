import { c as unfriendly_hydratable, i as parse_remote_arg, o as stringify, r as create_remote_key, s as stringify_remote_arg, v as noop } from "./chunks/shared.js";
import { d as base, l as app_dir, t as prerendering } from "./chunks/environment.js";
import { S as set_nested_value, T as MUTATIVE_METHODS, _ as create_field_proxy, b as flatten_issues, o as handle_error_and_jsonify, v as deep_set, x as normalize_issue } from "./chunks/utils.js";
import { error, json } from "@sveltejs/kit";
import { HttpError, SvelteKitError, ValidationError } from "@sveltejs/kit/internal";
import { get_request_store, with_request_store } from "@sveltejs/kit/internal/server";
import { parse } from "devalue";
//#region node_modules/@sveltejs/kit/src/runtime/app/server/remote/shared.js
/** @import { RequestEvent } from '@sveltejs/kit' */
/** @import { ServerHooks, MaybePromise, RequestState, RemoteInternals, RequestStore, RemoteLiveQueryUserFunctionReturnType } from 'types' */
/**
* @param {any} validate_or_fn
* @param {((arg?: any) => any) | undefined} [maybe_fn]
* @returns {(arg?: any) => MaybePromise<any>}
*/
function create_validator(validate_or_fn, maybe_fn) {
	if (!maybe_fn) return (arg) => {
		if (arg !== void 0) error(400, "Bad Request");
	};
	if (validate_or_fn === "unchecked") return (arg) => arg;
	if ("~standard" in validate_or_fn) return async (arg) => {
		const { event, state } = get_request_store();
		const result = await validate_or_fn["~standard"].validate(arg);
		if (result.issues) error(400, await state.handleValidationError({
			issues: result.issues,
			event
		}));
		return result.value;
	};
	throw new Error("Invalid validator passed to remote function. Expected \"unchecked\" or a Standard Schema (https://standardschema.dev)");
}
/**
* In case of a single remote function call, just returns the result.
*
* In case of a full page reload, returns the response for a remote function call,
* either from the cache or by invoking the function.
* Also saves an uneval'ed version of the result for later HTML inlining for hydration.
*
* @template {MaybePromise<any>} T
* @param {RemoteInternals} internals
* @param {string} payload — the stringified raw argument (i.e. the cache key the client will use)
* @param {RequestState} state
* @param {() => Promise<T>} get_result
* @returns {Promise<T>}
*/
async function get_response(internals, payload, state, get_result) {
	await 0;
	const cache = get_cache(internals, state);
	const entry = cache[payload] ??= {
		serialize: false,
		data: get_result()
	};
	entry.serialize ||= !!state.is_in_universal_load;
	if (state.is_in_render && internals.id) {
		const remote_key = create_remote_key(internals.id, payload);
		Promise.resolve(entry.data).then((value) => {
			unfriendly_hydratable(remote_key, () => stringify(value, state.transport));
		}).catch(noop);
	}
	return entry.data;
}
/**
* @param {any} data
* @param {ServerHooks['transport']} transport
*/
function parse_remote_response(data, transport) {
	/** @type {Record<string, any>} */
	const revivers = {};
	for (const key in transport) revivers[key] = transport[key].decode;
	return parse(data, revivers);
}
/**
* @param {RequestEvent} event
* @param {RequestState} state
* @param {boolean} allow_cookies
* @returns {RequestStore}
*/
function derive_remote_function_event(event, state, allow_cookies) {
	return {
		event: {
			...event,
			setHeaders: () => {
				throw new Error("setHeaders is not allowed in remote functions");
			},
			cookies: {
				...event.cookies,
				set: (name, value, opts) => {
					if (!allow_cookies) throw new Error("Cannot set cookies in `query` or `prerender` functions");
					if (opts.path && !opts.path.startsWith("/")) throw new Error("Cookies set in remote functions must have an absolute path");
					return event.cookies.set(name, value, opts);
				},
				delete: (name, opts) => {
					if (!allow_cookies) throw new Error("Cannot delete cookies in `query` or `prerender` functions");
					if (opts.path && !opts.path.startsWith("/")) throw new Error("Cookies deleted in remote functions must have an absolute path");
					return event.cookies.delete(name, opts);
				}
			}
		},
		state: {
			...state,
			is_in_remote_function: true
		}
	};
}
/**
* Like `with_event` but removes things from `event` you cannot see/call in remote functions, such as `setHeaders`.
* @template T
* @param {RequestEvent} event
* @param {RequestState} state
* @param {boolean} allow_cookies
* @param {() => any} get_input
* @param {(arg?: any) => T} fn
*/
async function run_remote_function(event, state, allow_cookies, get_input, fn) {
	const store = derive_remote_function_event(event, state, allow_cookies);
	const input = await with_request_store(store, get_input);
	return with_request_store(store, () => fn(input));
}
/**
* Like `with_event` but removes things from `event` you cannot see/call in remote functions, such as `setHeaders`.
* @template T
* @param {RequestEvent} event
* @param {RequestState} state
* @param {boolean} allow_cookies
* @param {() => any} get_input
* @param {(arg?: any) => RemoteLiveQueryUserFunctionReturnType<T>} fn
* @param {string} name
*/
async function* run_remote_generator(event, state, allow_cookies, get_input, fn, name) {
	const store = derive_remote_function_event(event, state, allow_cookies);
	const input = await with_request_store(store, get_input);
	const iterator = to_iterator(await with_request_store(store, () => fn(input)), name);
	let done = false;
	try {
		while (true) {
			const result = await with_request_store(store, () => iterator.next());
			if (result.done) {
				done = true;
				return result.value;
			}
			yield result.value;
		}
	} finally {
		if (!done && typeof iterator.return === "function") await with_request_store(store, () => iterator.return?.(void 0));
	}
}
/**
* @template T
* @param {Awaited<RemoteLiveQueryUserFunctionReturnType<T>>} source
* @param {string} name
* @returns {Iterator<T> | AsyncIterator<T>}
*/
function to_iterator(source, name) {
	if ("next" in source && typeof source.next === "function") return source;
	if (Symbol.asyncIterator in source && typeof source[Symbol.asyncIterator] === "function") return source[Symbol.asyncIterator]();
	if (Symbol.iterator in source && typeof source[Symbol.iterator] === "function") return source[Symbol.iterator]();
	throw new Error(`query.live '${name}' must return an Iterator, Iterable, AsyncIterator or AsyncIterable`);
}
/**
* @param {RemoteInternals} internals
* @param {RequestState} state
*/
function get_cache(internals, state = get_request_store().state) {
	let cache = state.remote.data?.get(internals);
	if (cache === void 0) {
		cache = {};
		(state.remote.data ??= /* @__PURE__ */ new Map()).set(internals, cache);
	}
	return cache;
}
//#endregion
//#region node_modules/@sveltejs/kit/src/runtime/app/server/remote/command.js
/** @import { RemoteCommand } from '@sveltejs/kit' */
/** @import { MaybePromise, RemoteCommandInternals } from 'types' */
/** @import { StandardSchemaV1 } from '@standard-schema/spec' */
/**
* Creates a remote command. When called from the browser, the function will be invoked on the server via a `fetch` call.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#command) for full documentation.
*
* @template Output
* @overload
* @param {() => MaybePromise<Output>} fn
* @returns {RemoteCommand<void, Output>}
* @since 2.27
*/
/**
* Creates a remote command. When called from the browser, the function will be invoked on the server via a `fetch` call.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#command) for full documentation.
*
* @template Input
* @template Output
* @overload
* @param {'unchecked'} validate
* @param {(arg: Input) => MaybePromise<Output>} fn
* @returns {RemoteCommand<Input, Output>}
* @since 2.27
*/
/**
* Creates a remote command. When called from the browser, the function will be invoked on the server via a `fetch` call.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#command) for full documentation.
*
* @template {StandardSchemaV1} Schema
* @template Output
* @overload
* @param {Schema} validate
* @param {(arg: StandardSchemaV1.InferOutput<Schema>) => MaybePromise<Output>} fn
* @returns {RemoteCommand<StandardSchemaV1.InferInput<Schema>, Output>}
* @since 2.27
*/
/**
* @template Input
* @template Output
* @param {any} validate_or_fn
* @param {(arg?: Input) => MaybePromise<Output>} [maybe_fn]
* @returns {RemoteCommand<Input, Output>}
* @since 2.27
*/
/* @__NO_SIDE_EFFECTS__ */
function command(validate_or_fn, maybe_fn) {
	/** @type {(arg?: Input) => MaybePromise<Output>} */
	const fn = maybe_fn ?? validate_or_fn;
	/** @type {(arg?: any) => MaybePromise<Input>} */
	const validate = create_validator(validate_or_fn, maybe_fn);
	/** @type {RemoteCommandInternals} */
	const __ = {
		type: "command",
		id: "",
		name: ""
	};
	/** @type {RemoteCommand<Input, Output> & { __: RemoteCommandInternals }} */
	const wrapper = (arg) => {
		const { event, state } = get_request_store();
		if (!MUTATIVE_METHODS.includes(event.request.method)) throw new Error(`Cannot call a command (\`${__.name}(${maybe_fn ? "..." : ""})\`) from a ${event.request.method} handler`);
		if (state.is_in_render) throw new Error(`Cannot call a command (\`${__.name}(${maybe_fn ? "..." : ""})\`) during server-side rendering`);
		state.remote.refreshes ??= /* @__PURE__ */ new Map();
		state.remote.reconnects ??= /* @__PURE__ */ new Map();
		const promise = Promise.resolve(run_remote_function(event, state, true, () => validate(arg), fn));
		promise.updates = () => {
			throw new Error(`Cannot call '${__.name}(...).updates(...)' on the server`);
		};
		return promise;
	};
	Object.defineProperty(wrapper, "__", { value: __ });
	Object.defineProperty(wrapper, "pending", { get: () => 0 });
	return wrapper;
}
//#endregion
//#region node_modules/@sveltejs/kit/src/runtime/app/server/remote/form.js
/** @import { RemoteFormInput, RemoteForm, InvalidField } from '@sveltejs/kit' */
/** @import { InternalRemoteFormIssue, MaybePromise, RemoteFormInternals } from 'types' */
/** @import { StandardSchemaV1 } from '@standard-schema/spec' */
/**
* Creates a form object that can be spread onto a `<form>` element.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#form) for full documentation.
*
* @template Output
* @overload
* @param {() => MaybePromise<Output>} fn
* @returns {RemoteForm<void, Output>}
* @since 2.27
*/
/**
* Creates a form object that can be spread onto a `<form>` element.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#form) for full documentation.
*
* @template {RemoteFormInput} Input
* @template Output
* @overload
* @param {'unchecked'} validate
* @param {(data: Input, issue: InvalidField<Input>) => MaybePromise<Output>} fn
* @returns {RemoteForm<Input, Output>}
* @since 2.27
*/
/**
* Creates a form object that can be spread onto a `<form>` element.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#form) for full documentation.
*
* @template {StandardSchemaV1<RemoteFormInput, Record<string, any>>} Schema
* @template Output
* @overload
* @param {Schema} validate
* @param {(data: StandardSchemaV1.InferOutput<Schema>, issue: InvalidField<StandardSchemaV1.InferInput<Schema>>) => MaybePromise<Output>} fn
* @returns {RemoteForm<StandardSchemaV1.InferInput<Schema>, Output>}
* @since 2.27
*/
/**
* @template {RemoteFormInput} Input
* @template Output
* @param {any} validate_or_fn
* @param {(data_or_issue: any, issue?: any) => MaybePromise<Output>} [maybe_fn]
* @returns {RemoteForm<Input, Output>}
* @since 2.27
*/
/* @__NO_SIDE_EFFECTS__ */
function form(validate_or_fn, maybe_fn) {
	/** @type {any} */
	const fn = maybe_fn ?? validate_or_fn;
	/** @type {StandardSchemaV1 | null} */
	const schema = !maybe_fn || validate_or_fn === "unchecked" ? null : validate_or_fn;
	/**
	* @param {string | number | boolean} [key]
	*/
	function create_instance(key) {
		/** @type {RemoteForm<Input, Output>} */
		const instance = {};
		instance.method = "POST";
		Object.defineProperty(instance, "enhance", { value: () => {
			return {
				action: instance.action,
				method: instance.method
			};
		} });
		/** @type {RemoteFormInternals} */
		const __ = {
			type: "form",
			name: "",
			id: "",
			fn: async (data, meta, form_data) => {
				/** @type {{ submission: true, input?: Record<string, any>, issues?: InternalRemoteFormIssue[], result: Output }} */
				const output = {};
				output.submission = true;
				const { event, state } = get_request_store();
				const validated = await schema?.["~standard"].validate(data);
				if (meta.validate_only) return validated?.issues?.map((issue) => normalize_issue(issue, true)) ?? [];
				if (validated?.issues !== void 0) handle_issues(output, validated.issues, form_data);
				else {
					if (validated !== void 0) data = validated.value;
					state.remote.refreshes ??= /* @__PURE__ */ new Map();
					state.remote.reconnects ??= /* @__PURE__ */ new Map();
					const issue = create_issues();
					try {
						output.result = await run_remote_function(event, state, true, () => data, (data) => !maybe_fn ? fn() : fn(data, issue));
					} catch (e) {
						if (e instanceof ValidationError) handle_issues(output, e.issues, form_data);
						else throw e;
					}
				}
				if (!event.isRemoteRequest) get_cache(__, state)[""] ??= {
					serialize: true,
					data: output
				};
				return output;
			}
		};
		Object.defineProperty(instance, "__", { value: __ });
		Object.defineProperty(instance, "action", {
			get: () => `?/remote=${__.id}`,
			enumerable: true
		});
		Object.defineProperty(instance, "fields", { get() {
			return create_field_proxy({}, () => get_cache(__)?.[""]?.data?.input ?? {}, (path, value) => {
				const cache = get_cache(__);
				const entry = cache[""];
				if (entry?.data?.submission) return;
				if (path.length === 0) {
					(cache[""] ??= {
						serialize: true,
						data: {}
					}).data.input = value;
					return;
				}
				const input = entry?.data?.input ?? {};
				deep_set(input, path.map(String), value);
				(cache[""] ??= {
					serialize: true,
					data: {}
				}).data.input = input;
			}, () => flatten_issues(get_cache(__)?.[""]?.data?.issues ?? []));
		} });
		Object.defineProperty(instance, "result", { get() {
			try {
				return get_cache(__)?.[""]?.data?.result;
			} catch {
				return;
			}
		} });
		Object.defineProperty(instance, "pending", { get: () => 0 });
		Object.defineProperty(instance, "preflight", { value: () => instance });
		Object.defineProperty(instance, "validate", { value: () => {
			throw new Error("Cannot call validate() on the server");
		} });
		if (key == void 0) Object.defineProperty(instance, "for", { 
		/** @type {RemoteForm<any, any>['for']} */
value: (key) => {
			const { state } = get_request_store();
			const cache_key = __.id + "|" + JSON.stringify(key);
			let instance = (state.remote.forms ??= /* @__PURE__ */ new Map()).get(cache_key);
			if (!instance) {
				instance = create_instance(key);
				instance.__.id = `${__.id}/${encodeURIComponent(JSON.stringify(key))}`;
				instance.__.name = __.name;
				state.remote.forms.set(cache_key, instance);
			}
			return instance;
		} });
		return instance;
	}
	return create_instance();
}
/**
* @param {{ issues?: InternalRemoteFormIssue[], input?: Record<string, any>, result: any }} output
* @param {readonly StandardSchemaV1.Issue[]} issues
* @param {FormData | null} form_data - null if the form is progressively enhanced
*/
function handle_issues(output, issues, form_data) {
	output.issues = issues.map((issue) => normalize_issue(issue, true));
	if (form_data) {
		output.input = {};
		for (let key of form_data.keys()) {
			if (/^[.\]]?_/.test(key)) continue;
			const is_array = key.endsWith("[]");
			const values = form_data.getAll(key).filter((value) => typeof value === "string");
			if (is_array) key = key.slice(0, -2);
			set_nested_value(output.input, key, is_array ? values : values[0]);
		}
	}
}
/**
* Creates an invalid function that can be used to imperatively mark form fields as invalid
* @returns {InvalidField<any>}
*/
function create_issues() {
	return new Proxy(
		/** @param {string} message */
		(message) => {
			if (typeof message !== "string") throw new Error("`invalid` should now be imported from `@sveltejs/kit` to throw validation issues. The second parameter provided to the form function (renamed to `issue`) is still used to construct issues, e.g. `invalid(issue.field('message'))`. For more info see https://github.com/sveltejs/kit/pulls/14768");
			return create_issue(message);
		},
		{ get(target, prop) {
			if (typeof prop === "symbol") return target[prop];
			return create_issue_proxy(prop, []);
		} }
	);
	/**
	* @param {string} message
	* @param {(string | number)[]} path
	* @returns {StandardSchemaV1.Issue}
	*/
	function create_issue(message, path = []) {
		return {
			message,
			path
		};
	}
	/**
	* Creates a proxy that builds up a path and returns a function to create an issue
	* @param {string | number} key
	* @param {(string | number)[]} path
	*/
	function create_issue_proxy(key, path) {
		const new_path = [...path, key];
		/**
		* @param {string} message
		* @returns {StandardSchemaV1.Issue}
		*/
		const issue_func = (message) => create_issue(message, new_path);
		return new Proxy(issue_func, { get(target, prop) {
			if (typeof prop === "symbol") return target[prop];
			if (/^\d+$/.test(prop)) return create_issue_proxy(parseInt(prop, 10), new_path);
			return create_issue_proxy(prop, new_path);
		} });
	}
}
//#endregion
//#region node_modules/@sveltejs/kit/src/runtime/app/server/remote/prerender.js
/** @import { RemoteResource, RemotePrerenderFunction } from '@sveltejs/kit' */
/** @import { RemotePrerenderInputsGenerator, RemotePrerenderInternals, MaybePromise } from 'types' */
/** @import { StandardSchemaV1 } from '@standard-schema/spec' */
/**
* Creates a remote prerender function. When called from the browser, the function will be invoked on the server via a `fetch` call.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#prerender) for full documentation.
*
* @template Output
* @overload
* @param {() => MaybePromise<Output>} fn
* @param {{ inputs?: RemotePrerenderInputsGenerator<void>, dynamic?: boolean }} [options]
* @returns {RemotePrerenderFunction<void, Output>}
* @since 2.27
*/
/**
* Creates a remote prerender function. When called from the browser, the function will be invoked on the server via a `fetch` call.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#prerender) for full documentation.
*
* @template Input
* @template Output
* @overload
* @param {'unchecked'} validate
* @param {(arg: Input) => MaybePromise<Output>} fn
* @param {{ inputs?: RemotePrerenderInputsGenerator<Input>, dynamic?: boolean }} [options]
* @returns {RemotePrerenderFunction<Input, Output>}
* @since 2.27
*/
/**
* Creates a remote prerender function. When called from the browser, the function will be invoked on the server via a `fetch` call.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#prerender) for full documentation.
*
* @template {StandardSchemaV1} Schema
* @template Output
* @overload
* @param {Schema} schema
* @param {(arg: StandardSchemaV1.InferOutput<Schema>) => MaybePromise<Output>} fn
* @param {{ inputs?: RemotePrerenderInputsGenerator<StandardSchemaV1.InferInput<Schema>>, dynamic?: boolean }} [options]
* @returns {RemotePrerenderFunction<StandardSchemaV1.InferInput<Schema>, Output>}
* @since 2.27
*/
/**
* @template Input
* @template Output
* @param {any} validate_or_fn
* @param {any} [fn_or_options]
* @param {{ inputs?: RemotePrerenderInputsGenerator<Input>, dynamic?: boolean }} [maybe_options]
* @returns {RemotePrerenderFunction<Input, Output>}
* @since 2.27
*/
/* @__NO_SIDE_EFFECTS__ */
function prerender(validate_or_fn, fn_or_options, maybe_options) {
	const maybe_fn = typeof fn_or_options === "function" ? fn_or_options : void 0;
	/** @type {typeof maybe_options} */
	const options = maybe_options ?? (maybe_fn ? void 0 : fn_or_options);
	/** @type {(arg?: Input) => MaybePromise<Output>} */
	const fn = maybe_fn ?? validate_or_fn;
	/** @type {(arg?: any) => MaybePromise<Input>} */
	const validate = create_validator(validate_or_fn, maybe_fn);
	/** @type {RemotePrerenderInternals} */
	const __ = {
		type: "prerender",
		id: "",
		name: "",
		has_arg: !!maybe_fn,
		inputs: options?.inputs,
		dynamic: options?.dynamic
	};
	/** @type {RemotePrerenderFunction<Input, Output> & { __: RemotePrerenderInternals }} */
	const wrapper = (arg) => {
		/** @type {Promise<Output> & Partial<RemoteResource<Output>>} */
		const promise = (async () => {
			const { event, state } = get_request_store();
			const payload = stringify_remote_arg(arg, state.transport);
			const url = `${base}/${app_dir}/remote/${__.id}${payload ? `/${payload}` : ""}`;
			if (!state.prerendering && !event.isRemoteRequest) try {
				return await get_response(__, payload, state, async () => {
					const cache = get_cache(__, state);
					const promise = (cache[payload] ??= {
						serialize: true,
						data: fetch(new URL(url, event.url.origin).href).then(async (response) => {
							if (!response.ok) throw new Error("Prerendered response not found");
							const prerendered = await response.json();
							if (prerendered.type === "error") error(prerendered.status, prerendered.error);
							return prerendered.result;
						})
					}).data;
					return parse_remote_response(await promise, state.transport);
				});
			} catch {}
			if (state.prerendering?.remote_responses.has(url)) return state.prerendering.remote_responses.get(url);
			const promise = get_response(__, payload, state, () => run_remote_function(event, state, false, () => validate(arg), fn));
			if (state.prerendering) state.prerendering.remote_responses.set(url, promise);
			const result = await promise;
			if (state.prerendering) {
				const body = {
					type: "result",
					result: stringify(result, state.transport)
				};
				state.prerendering.dependencies.set(url, {
					body: JSON.stringify(body),
					response: json(body)
				});
			}
			return result;
		})();
		promise.catch(noop);
		return promise;
	};
	Object.defineProperty(wrapper, "__", { value: __ });
	return wrapper;
}
//#endregion
//#region node_modules/@sveltejs/kit/src/runtime/app/server/remote/query.js
/** @import { RemoteLiveQuery, RemoteLiveQueryFunction, RemoteQuery, RemoteQueryFunction } from '@sveltejs/kit' */
/** @import { RemoteInternals, MaybePromise, RequestState, RemoteQueryLiveInternals, RemoteQueryBatchInternals, RemoteQueryInternals, RemoteLiveQueryUserFunctionReturnType } from 'types' */
/** @import { StandardSchemaV1 } from '@standard-schema/spec' */
/**
* Creates a remote query. When called from the browser, the function will be invoked on the server via a `fetch` call.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#query) for full documentation.
*
* @template Output
* @overload
* @param {() => MaybePromise<Output>} fn
* @returns {RemoteQueryFunction<void, Output>}
* @since 2.27
*/
/**
* Creates a remote query. When called from the browser, the function will be invoked on the server via a `fetch` call.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#query) for full documentation.
*
* @template Input
* @template Output
* @overload
* @param {'unchecked'} validate
* @param {(arg: Input) => MaybePromise<Output>} fn
* @returns {RemoteQueryFunction<Input, Output>}
* @since 2.27
*/
/**
* Creates a remote query. When called from the browser, the function will be invoked on the server via a `fetch` call.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#query) for full documentation.
*
* @template {StandardSchemaV1} Schema
* @template Output
* @overload
* @param {Schema} schema
* @param {(arg: StandardSchemaV1.InferOutput<Schema>) => MaybePromise<Output>} fn
* @returns {RemoteQueryFunction<StandardSchemaV1.InferInput<Schema>, Output, StandardSchemaV1.InferOutput<Schema>>}
* @since 2.27
*/
/**
* @template Input
* @template Output
* @param {any} validate_or_fn
* @param {(args?: Input) => MaybePromise<Output>} [maybe_fn]
* @returns {RemoteQueryFunction<Input, Output>}
* @since 2.27
*/
/* @__NO_SIDE_EFFECTS__ */
function query(validate_or_fn, maybe_fn) {
	/** @type {(arg?: Input) => Output} */
	const fn = maybe_fn ?? validate_or_fn;
	/** @type {(arg?: any) => MaybePromise<Input>} */
	const validate = create_validator(validate_or_fn, maybe_fn);
	/** @type {RemoteQueryInternals} */
	const __ = {
		type: "query",
		id: "",
		name: "",
		validate,
		bind(payload, validated_arg) {
			const { event, state } = get_request_store();
			return create_query_resource(__, payload, state, () => run_remote_function(event, state, false, () => validated_arg, fn));
		}
	};
	/** @type {RemoteQueryFunction<Input, Output> & { __: RemoteQueryInternals }} */
	const wrapper = (arg) => {
		if (prerendering) throw new Error(`Cannot call query '${__.name}' while prerendering, as prerendered pages need static data. Use 'prerender' from $app/server instead`);
		const { event, state } = get_request_store();
		return create_query_resource(__, stringify_remote_arg(arg, state.transport), state, () => run_remote_function(event, state, false, () => validate(arg), fn));
	};
	Object.defineProperty(wrapper, "__", { value: __ });
	return wrapper;
}
/**
* Creates a live remote query. When called from the browser, the function will be invoked on the server via a streaming `fetch` call.
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#query.live) for full documentation.
*
* @template Output
* @overload
* @param {(arg: void) => RemoteLiveQueryUserFunctionReturnType<Output>} fn
* @returns {RemoteLiveQueryFunction<void, Output>}
*/
/**
* @template Input
* @template Output
* @overload
* @param {'unchecked'} validate
* @param {(arg: Input) => RemoteLiveQueryUserFunctionReturnType<Output>} fn
* @returns {RemoteLiveQueryFunction<Input, Output>}
*/
/**
* @template {StandardSchemaV1} Schema
* @template Output
* @overload
* @param {Schema} schema
* @param {(arg: StandardSchemaV1.InferOutput<Schema>) => RemoteLiveQueryUserFunctionReturnType<Output>} fn
* @returns {RemoteLiveQueryFunction<StandardSchemaV1.InferInput<Schema>, Output, StandardSchemaV1.InferOutput<Schema>>}
*/
/**
* @template Input
* @template Output
* @param {any} validate_or_fn
* @param {(args: Input) => RemoteLiveQueryUserFunctionReturnType<Output>} [maybe_fn]
* @returns {RemoteLiveQueryFunction<Input, Output>}
*/
/* @__NO_SIDE_EFFECTS__ */
function live(validate_or_fn, maybe_fn) {
	/** @type {(arg: Input) => RemoteLiveQueryUserFunctionReturnType<Output>} */
	const fn = maybe_fn ?? validate_or_fn;
	/** @type {(arg?: any) => MaybePromise<Input>} */
	const validate = create_validator(validate_or_fn, maybe_fn);
	/**
	* @param {any} event
	* @param {any} state
	* @param {any} get_input
	*/
	const run = (event, state, get_input) => run_remote_generator(event, state, false, get_input, fn, __.name);
	/**
	* @param {any} generator
	* @returns {Promise<any>}
	*/
	const first_value = async (generator) => {
		try {
			const { value, done } = await generator.next();
			if (done) throw new Error(`query.live '${__.name}' did not yield a value`);
			return value;
		} finally {
			await generator.return(void 0);
		}
	};
	/** @type {RemoteQueryLiveInternals} */
	const __ = {
		type: "query_live",
		id: "",
		name: "",
		run: (event, state, arg) => run(event, state, () => validate(arg)),
		validate,
		bind(payload, validated_arg) {
			const { event, state } = get_request_store();
			return create_live_query_resource(__, payload, state, () => first_value(run(event, state, () => validated_arg)));
		}
	};
	/** @type {RemoteLiveQueryFunction<Input, Output> & { __: RemoteQueryLiveInternals }} */
	const wrapper = (arg) => {
		if (prerendering) throw new Error(`Cannot call query.live '${__.name}' while prerendering, as prerendered pages need static data. Use 'prerender' from $app/server instead`);
		const { event, state } = get_request_store();
		return create_live_query_resource(__, stringify_remote_arg(arg, state.transport), state, () => first_value(run(event, state, () => validate(arg))));
	};
	Object.defineProperty(wrapper, "__", { value: __ });
	return wrapper;
}
/**
* Creates a batch query function that collects multiple calls and executes them in a single request
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#query.batch) for full documentation.
*
* @template Input
* @template Output
* @overload
* @param {'unchecked'} validate
* @param {(args: Input[]) => MaybePromise<(arg: Input, idx: number) => Output>} fn
* @returns {RemoteQueryFunction<Input, Output>}
* @since 2.35
*/
/**
* Creates a batch query function that collects multiple calls and executes them in a single request
*
* See [Remote functions](https://svelte.dev/docs/kit/remote-functions#query.batch) for full documentation.
*
* @template {StandardSchemaV1} Schema
* @template Output
* @overload
* @param {Schema} schema
* @param {(args: StandardSchemaV1.InferOutput<Schema>[]) => MaybePromise<(arg: StandardSchemaV1.InferOutput<Schema>, idx: number) => Output>} fn
* @returns {RemoteQueryFunction<StandardSchemaV1.InferInput<Schema>, Output, StandardSchemaV1.InferOutput<Schema>>}
* @since 2.35
*/
/**
* @template Input
* @template Output
* @param {any} validate_or_fn
* @param {(args?: Input[]) => MaybePromise<(arg: Input, idx: number) => Output>} [maybe_fn]
* @returns {RemoteQueryFunction<Input, Output>}
* @since 2.35
*/
/* @__NO_SIDE_EFFECTS__ */
function batch(validate_or_fn, maybe_fn) {
	/** @type {(args?: Input[]) => MaybePromise<(arg: Input, idx: number) => Output>} */
	const fn = maybe_fn ?? validate_or_fn;
	/** @type {(arg?: any) => MaybePromise<Input>} */
	const validate = create_validator(validate_or_fn, maybe_fn);
	/** @type {Map<string, { get_validated: () => MaybePromise<any>, resolvers: Array<{resolve: (value: any) => void, reject: (error: any) => void}> }>} */
	let batching = /* @__PURE__ */ new Map();
	/**
	* Enqueues a single call into the current batch (creating one if necessary)
	* and returns a promise that resolves with the result for this entry.
	*
	* @param {string} payload — the stringified raw argument (cache key)
	* @param {() => MaybePromise<any>} get_validated — produces the validated argument for this entry
	* @returns {Promise<any>}
	*/
	const enqueue = (payload, get_validated) => {
		const { event, state } = get_request_store();
		return new Promise((resolve, reject) => {
			const entry = batching.get(payload);
			if (entry) {
				entry.resolvers.push({
					resolve,
					reject
				});
				return;
			}
			batching.set(payload, {
				get_validated,
				resolvers: [{
					resolve,
					reject
				}]
			});
			if (batching.size > 1) return;
			setTimeout(async () => {
				const batched = batching;
				batching = /* @__PURE__ */ new Map();
				const entries = Array.from(batched.values());
				try {
					return await run_remote_function(event, state, false, async () => Promise.all(entries.map((entry) => entry.get_validated())), async (input) => {
						const get_result = await fn(input);
						for (let i = 0; i < entries.length; i++) try {
							const result = get_result(input[i], i);
							for (const resolver of entries[i].resolvers) resolver.resolve(result);
						} catch (error) {
							for (const resolver of entries[i].resolvers) resolver.reject(error);
						}
					});
				} catch (error) {
					for (const entry of batched.values()) for (const resolver of entry.resolvers) resolver.reject(error);
				}
			}, 0);
		});
	};
	/** @type {RemoteQueryBatchInternals} */
	const __ = {
		type: "query_batch",
		id: "",
		name: "",
		validate,
		run: async (args, options) => {
			const { event, state } = get_request_store();
			return run_remote_function(event, state, false, async () => Promise.all(args.map(validate)), async (input) => {
				const get_result = await fn(input);
				return Promise.all(input.map(async (arg, i) => {
					try {
						return {
							type: "result",
							data: stringify(get_result(arg, i), state.transport)
						};
					} catch (error) {
						return {
							type: "error",
							error: await handle_error_and_jsonify(event, state, options, error),
							status: error instanceof HttpError || error instanceof SvelteKitError ? error.status : 500
						};
					}
				}));
			});
		},
		bind(payload, validated_arg) {
			const { state } = get_request_store();
			return create_query_resource(__, payload, state, () => enqueue(payload, () => validated_arg));
		}
	};
	/** @type {RemoteQueryFunction<Input, Output> & { __: RemoteQueryBatchInternals }} */
	const wrapper = (arg) => {
		if (prerendering) throw new Error(`Cannot call query.batch '${__.name}' while prerendering, as prerendered pages need static data. Use 'prerender' from $app/server instead`);
		const { state } = get_request_store();
		const payload = stringify_remote_arg(arg, state.transport);
		return create_query_resource(__, payload, state, () => enqueue(payload, () => validate(arg)));
	};
	Object.defineProperty(wrapper, "__", { value: __ });
	return wrapper;
}
/**
* @param {RemoteInternals} __
* @param {string} payload — the stringified raw argument (i.e. the cache key the client will use)
* @param {RequestState} state
* @param {() => Promise<any>} fn
* @returns {RemoteQuery<any>}
*/
function create_query_resource(__, payload, state, fn) {
	/** @type {Promise<any> | null} */
	let promise = null;
	const get_promise = () => {
		return promise ??= get_response(__, payload, state, fn);
	};
	const populate_hydratable = () => {
		__.id && state.is_in_render && get_promise();
	};
	return {
		/** @type {Promise<any>['catch']} */
		catch(onrejected) {
			return get_promise().catch(onrejected);
		},
		get current() {
			populate_hydratable();
		},
		get error() {
			populate_hydratable();
		},
		/** @type {Promise<any>['finally']} */
		finally(onfinally) {
			return get_promise().finally(onfinally);
		},
		get loading() {
			populate_hydratable();
			return true;
		},
		get ready() {
			populate_hydratable();
			return false;
		},
		refresh() {
			const refresh_context = get_refresh_context(__, "refresh", payload);
			const is_immediate_refresh = !refresh_context.cache[refresh_context.payload];
			return update_refresh_value(refresh_context, is_immediate_refresh ? get_promise() : fn(), is_immediate_refresh);
		},
		run() {
			if (!state.is_in_universal_load) throw new Error("On the server, .run() can only be called in universal `load` functions. Anywhere else, just await the query directly");
			return get_response(__, payload, state, fn);
		},
		/** @param {any} value */
		set(value) {
			return update_refresh_value(get_refresh_context(__, "set", payload), value);
		},
		/** @type {Promise<any>['then']} */
		then(onfulfilled, onrejected) {
			return get_promise().then(onfulfilled, onrejected);
		},
		withOverride() {
			throw new Error(`Cannot call '${__.name}.withOverride()' on the server`);
		},
		get [Symbol.toStringTag]() {
			return "QueryResource";
		}
	};
}
/**
* @param {RemoteQueryLiveInternals} __
* @param {string} payload — the stringified raw argument (i.e. the cache key the client will use)
* @param {RequestState} state
* @param {() => Promise<any>} get_first_value
* @returns {RemoteLiveQuery<any>}
*/
function create_live_query_resource(__, payload, state, get_first_value) {
	/** @type {Promise<any> | null} */
	let promise = null;
	const get_promise = () => {
		return promise ??= get_response(__, payload, state, get_first_value);
	};
	const populate_hydratable = () => {
		__.id && state.is_in_render && get_promise();
	};
	return {
		/** @type {Promise<any>['catch']} */
		catch(onrejected) {
			return get_promise().catch(onrejected);
		},
		get current() {
			populate_hydratable();
		},
		get error() {
			populate_hydratable();
		},
		/** @type {Promise<any>['finally']} */
		finally(onfinally) {
			return get_promise().finally(onfinally);
		},
		get done() {
			populate_hydratable();
			return false;
		},
		get loading() {
			populate_hydratable();
			return true;
		},
		get ready() {
			populate_hydratable();
			return false;
		},
		get connected() {
			populate_hydratable();
			return false;
		},
		reconnect() {
			const reconnects = state.remote.reconnects;
			if (!reconnects) throw new Error(`Cannot call reconnect on query.live '${__.name}' because it is not executed in the context of a command/form remote function`);
			reconnects.set(create_remote_key(__.id, payload), get_promise());
			return Promise.resolve();
		},
		run() {
			throw new Error("Cannot call .run() on a live query on the server");
		},
		/** @type {Promise<any>['then']} */
		then(onfulfilled, onrejected) {
			return get_promise().then(onfulfilled, onrejected);
		},
		get [Symbol.toStringTag]() {
			return "LiveQueryResource";
		}
	};
}
Object.defineProperty(query, "batch", {
	value: batch,
	enumerable: true
});
Object.defineProperty(query, "live", {
	value: live,
	enumerable: true
});
/**
* @param {RemoteInternals} __
* @param {'set' | 'refresh'} action
* @param {string} payload — the stringified raw argument (i.e. the cache key the client will use)
* @returns {{ __: RemoteInternals; state: any; refreshes: Map<string, Promise<any>>; cache: Record<string, { serialize: boolean; data: any }>; refreshes_key: string; payload: string }}
*/
function get_refresh_context(__, action, payload) {
	const { state } = get_request_store();
	const { refreshes } = state.remote;
	if (!refreshes) {
		const name = __.type === "query_batch" ? `query.batch '${__.name}'` : `query '${__.name}'`;
		throw new Error(`Cannot call ${action} on ${name} because it is not executed in the context of a command/form remote function`);
	}
	const cache = get_cache(__, state);
	return {
		__,
		state,
		refreshes,
		refreshes_key: create_remote_key(__.id, payload),
		cache,
		payload
	};
}
/**
* @param {{ __: RemoteInternals; refreshes: Map<string, Promise<any>>; cache: Record<string, { serialize: boolean; data: any }>; refreshes_key: string; payload: string }} context
* @param {any} value
* @param {boolean} [is_immediate_refresh=false]
* @returns {Promise<void>}
*/
function update_refresh_value({ __, refreshes, refreshes_key, cache, payload }, value, is_immediate_refresh = false) {
	const promise = Promise.resolve(value);
	if (!is_immediate_refresh) cache[payload] = {
		serialize: true,
		data: promise
	};
	if (__.id) refreshes.set(refreshes_key, promise);
	promise.catch(noop);
	return Promise.resolve();
}
//#endregion
//#region node_modules/@sveltejs/kit/src/runtime/app/server/remote/requested.js
/** @import { RemoteLiveQuery, RemoteLiveQueryFunction, RemoteQuery, RemoteQueryFunction, RequestedResult, QueryRequestedResult, LiveQueryRequestedResult } from '@sveltejs/kit' */
/** @import { MaybePromise, RemoteAnyQueryInternals } from 'types' */
/**
* In the context of a remote `command` or `form` request, returns an iterable
* of `{ arg, query }` entries for the refreshes requested by the client, up to
* the supplied `limit`. Each `query` is a `RemoteQuery` bound to the original
* client-side cache key, so `refresh()` / `set()` propagate correctly even when
* the query's schema transforms the input. `arg` is the *validated* argument,
* i.e. the value after the schema has run (so `InferOutput<Schema>` for queries
* declared with a Standard Schema).
*
* Arguments that fail validation or exceed `limit` are recorded as failures in
* the response to the client.
*
* @example
* ```ts
* import { requested } from '$app/server';
*
* for (const { arg, query } of requested(getPost, 5)) {
* 	// `arg` is the validated argument; `query` is bound to the client's
* 	// cache key. It's safe to throw away this promise -- SvelteKit will
* 	// await it and forward any errors to the client.
* 	void query.refresh();
* }
* ```
*
* As a shorthand for the above, you can also call `refreshAll` on the result:
*
* @example
* ```ts
* import { requested } from '$app/server';
*
* await requested(getPost, 5).refreshAll();
* ```
*
* Works with `query.batch` as well — refreshes for individual entries are
* collected into a single batched call.
*
* For live queries, the same applies, but with `reconnect` and `reconnectAll`.
*
* @template Input
* @template Output
* @template [Validated=Input]
* @overload
* @param {RemoteQueryFunction<Input, Output, Validated>} query
* @param {number} limit
* @returns {QueryRequestedResult<Validated, Output>}
*/
/**
* In the context of a remote `command` or `form` request, returns an iterable
* of `{ arg, query }` entries for the reconnects requested by the client, up to
* the supplied `limit`. Each `query` is a `RemoteLiveQuery` bound to the original
* client-side cache key, so `reconnect()` propagates correctly even when
* the query's schema transforms the input. `arg` is the *validated* argument.
*
* Arguments that fail validation or exceed `limit` are recorded as failures in
* the response to the client.
*
* @example
* ```ts
* import { requested } from '$app/server';
*
* for (const { query } of requested(getPost, 5)) {
* 	void query.reconnect();
* }
* ```
*
* As a shorthand, you can also call `reconnectAll` on the result:
*
* @example
* ```ts
* import { requested } from '$app/server';
*
* await requested(getPost, 5).reconnectAll();
* ```
*
* @template Input
* @template Output
* @template [Validated=Input]
* @overload
* @param {RemoteLiveQueryFunction<Input, Output, Validated>} query
* @param {number} limit
* @returns {LiveQueryRequestedResult<Validated, Output>}
*/
/**
* @template Input
* @template Output
* @template [Validated=Input]
* @param {RemoteQueryFunction<Input, Output, Validated> | RemoteLiveQueryFunction<Input, Output, Validated>} query
* @param {number} limit
* @returns {RequestedResult<Validated, Output>}
*/
function requested(query, limit) {
	const { state } = get_request_store();
	const internals = query.__;
	if (internals?.type !== "query" && internals?.type !== "query_batch" && internals?.type !== "query_live") throw new Error("requested(...) expects a query function created with query(...), query.batch(...), or query.live(...)");
	const __ = internals;
	const payloads = state.remote.requested?.get(__.id) ?? [];
	const refreshes = state.remote.refreshes;
	const reconnects = state.remote.reconnects;
	const store = __.type === "query_live" ? reconnects : refreshes;
	if (!store) throw new Error("requested(...) can only be called in the context of a command/form remote function");
	const [selected, skipped] = split_limit(payloads, limit);
	/**
	* @param {string} payload
	* @param {unknown} error
	*/
	const record_failure = (payload, error) => {
		const promise = Promise.reject(error);
		promise.catch(noop);
		const key = create_remote_key(__.id, payload);
		store.set(key, promise);
	};
	for (const payload of skipped) record_failure(payload, /* @__PURE__ */ new Error(`Requested refresh was rejected because it exceeded requested(${__.name}, ${limit}) limit`));
	const result = {
		*[Symbol.iterator]() {
			for (const payload of selected) try {
				const parsed = parse_remote_arg(payload, state.transport);
				const validated = __.validate(parsed);
				if (is_thenable(validated)) throw new Error(`requested(${__.name}, ${limit}) cannot be used with synchronous iteration because the query validator is async. Use \`for await ... of\` instead`);
				yield {
					arg: validated,
					query: __.bind(payload, validated)
				};
			} catch (error) {
				record_failure(payload, error);
				continue;
			}
		},
		async *[Symbol.asyncIterator]() {
			yield* race_all(selected, async (payload) => {
				try {
					const parsed = parse_remote_arg(payload, state.transport);
					const validated = await __.validate(parsed);
					return {
						arg: validated,
						query: __.bind(payload, validated)
					};
				} catch (error) {
					record_failure(payload, error);
					throw new Error(`Skipping ${__.name}(${payload})`, { cause: error });
				}
			});
		},
		async refreshAll() {
			if (__.type === "query_live") throw new Error("refreshAll() is invalid for live queries. Use reconnectAll() instead.");
			for await (const { query } of result) query.refresh();
		},
		async reconnectAll() {
			if (__.type !== "query_live") throw new Error("reconnectAll() is invalid for regular queries. Use refreshAll() instead.");
			for await (const { query } of result) query.reconnect();
		}
	};
	return result;
}
/**
* @template T
* @param {Array<T>} array
* @param {number} limit
* @returns {[Array<T>, Array<T>]}
*/
function split_limit(array, limit) {
	if (limit === Infinity) return [array, []];
	if (!Number.isInteger(limit) || limit < 0) throw new Error("Limit must be a non-negative integer or Infinity");
	return [array.slice(0, limit), array.slice(limit)];
}
/**
* @param {any} value
* @returns {value is PromiseLike<any>}
*/
function is_thenable(value) {
	return !!value && (typeof value === "object" || typeof value === "function") && "then" in value;
}
/**
* Runs all callbacks immediately and yields resolved values in completion order.
* If the promise rejects, it is skipped.
*
* @template T
* @template R
* @param {Array<T>} array
* @param {(value: T) => MaybePromise<R>} fn
* @returns {AsyncIterable<R>}
*/
async function* race_all(array, fn) {
	/** @type {Set<Promise<{ promise: Promise<any>, value: Awaited<R> }>>} */
	const pending = /* @__PURE__ */ new Set();
	for (const value of array) {
		/** @type {Promise<{ promise: Promise<any>, value: Awaited<R> }>} */
		const promise = Promise.resolve(fn(value)).then((result) => ({
			promise,
			value: result
		}));
		promise.catch(() => pending.delete(promise));
		pending.add(promise);
	}
	while (pending.size > 0) try {
		const { promise, value } = await Promise.race(pending);
		pending.delete(promise);
		yield value;
	} catch {}
}
//#endregion
export { command, form, prerender, query, requested };
