module WatcherDogService

go 1.25.0

require (
	golang.org/x/sys v0.47.0
)

require github.com/kardianos/service v1.3.0
